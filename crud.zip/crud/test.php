<?php
include 'database.php';

$obj = new query();

$condition_arr = array('name'=>"Amit Kumar",'email'=>"amit.kumar@gmail.com",'mobile'=>'8888888888');
//$result = $obj->getData('students','*','','id','asc',7);
//$result = $obj->insertData('students',$condition_arr);
//$result = $obj->deleteData('students',$condition_arr);

$result = $obj->updateData('students',$condition_arr,'id',9);

echo "<pre>";
print_r($result);


?>