<?php

class database{

	private $db_host;
	private $db_user;
	private $db_pass;
	private $db_name;

	protected function connect(){
		$this->db_host = "localhost";
		$this->db_user = "root";
		$this->db_pass = "";
		$this->db_name = "testing";

		$con = new mysqli($this->db_host, $this->db_user, $this->db_pass, $this->db_name);

		return $con;
	}
}

	class query extends database{

		//for fetch records from database
		public function getData($table,$field='*',$condition_arr='',$order_by_field='',$order_by_type='desc',$limit=''){
			$sql = " SELECT $field FROM $table ";

			if($condition_arr!=''){		
				$sql .=' where ';
				$c = count($condition_arr);
				$i = 1;
				foreach ($condition_arr as $key => $val) {
					if ($i == $c) {
						$sql .=" $key='$val' ";
					}
					else{
						$sql .=" $key='$val' and ";
					}
					$i++;
				}
			}

			if($order_by_field!=''){		
				$sql .=" order by $order_by_field $order_by_type ";
			}

			if($limit!=''){		
				$sql .=" limit $limit ";
			}
			//die($sql);
			$result=$this->connect()->query($sql);
			if($result->num_rows>0){
				$arr=array();
				while($row=$result->fetch_assoc()){
					$arr[]=$row;
				}
				return $arr;
			}else{
				return 0;
			}
			
		}

		//insert data into database 
		public function insertData($table,$condition_arr){

			if($condition_arr!=''){
				foreach ($condition_arr as $key => $val) {
					$fieldArr[] = $key;
					$valueArr[] = $val;
				}

				$field = implode(",",$fieldArr);
				$value = implode("','",$valueArr);
				$value = "'".$value."'";
				$sql = " INSERT INTO $table ($field) VALUES ($value) ";
				//die($sql);
				$result=$this->connect()->query($sql);
			}
		}

		//delete data from database 
		public function deleteData($table,$condition_arr){

			if($condition_arr!=''){
				$sql = " DELETE FROM $table WHERE ";
				$c = count($condition_arr);
				$i = 1;
				foreach ($condition_arr as $key => $val) {
					if ($i == $c) {
						$sql .=" $key='$val' ";
					}
					else{
						$sql .=" $key='$val' and ";
					}
					$i++;
				}
				
				//die($sql);
				$result=$this->connect()->query($sql);
			}
		}

		//Update data into database 
		public function updateData($table,$condition_arr,$where_field,$where_value){

			if($condition_arr!=''){
				$sql = " UPDATE $table SET ";
				$c = count($condition_arr);
				$i = 1;
				foreach ($condition_arr as $key => $val) {
					if ($i == $c) {
						$sql .=" $key='$val' ";
					}
					else{
						$sql .=" $key='$val', ";
					}
					$i++;
				}
				$sql .= " WHERE  $where_field='$where_value' ";
				//die($sql);
				$result=$this->connect()->query($sql);
			}
		}

		public function get_safe_str($str){
		if($str!=''){
			return mysqli_real_escape_string($this->connect(),$str);
		}
	}

	}





?>